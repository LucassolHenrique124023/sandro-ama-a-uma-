<?php

function ConverterEmMoeda($valor){
    return'R$ '.ConverterEmMoeda($valor,2,",",".");
}


?>