<?php
$paginaAtual = 'Produtos';
// add os arquivos
include_once'./includes/_functions.php';
include_once './includes/_head.php';#inclui o head da pagina
include_once './includes/_dados.php';#inclui os dados da pagina
//varial controle
include_once './includes/_header.php'#ativa o header da pagina
?>
 <main class='container'>
    <section id="produtos">
    <div class="row">
 <?php
 //laco de repeticao
 foreach ($dadosProdutos as $key => $value) {
 ?>
    <div class="card col-3" style="width: 18rem;">
    <a href="./produto-detalhe.php?id=<?php echo $key;?>">
  <img class="card-img-top" src="./produtos/<?php echo $value['imagem']?>"alt="<?php echo $value['nome'];?>">
  <div class="card-body">
  <h4 class="card-title"><?php echo $value['nome']?><h4>
      <aspan class="card-price">R$<?php echo $value['preco']?><span>
  </div>
</div>
    <?php
    }
    ?>
    </section>

<?php
include_once './includes/_footer.php'; #inclui o footer da pagina
?>
