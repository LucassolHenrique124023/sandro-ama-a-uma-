<?php
$paginaAtual = 'Receitas';
// add os arquivos
include_once'./includes/_functions.php';
include_once './includes/_head.php';#inclui o head da pagina
include_once './includes/_dados.php';#inclui os dados da pagina
//varial controle
include_once './includes/_header.php'#ativa o header da pagina
?>
